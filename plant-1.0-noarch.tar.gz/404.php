<?PHP
include("mainfile.php");
include("header.php");
$html = new html;
$html->page = "404.php";
$html->title = "File Not Found";
$html->do_header();
echo "<h1>File Not Found</h1>
The file you requested could not be found on this server.";
$html->do_footer();
