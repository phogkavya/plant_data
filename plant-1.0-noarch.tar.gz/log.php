<?PHP
/*************************************
 * log.php  v1.0                     *
 *   Ian Hill 2002                   *
 *                                   *
 * Logging facilites for Plant DB    *
 *                                   *
 * PROTOTYPE:                        *
 *    printl(level, message, file)   *
 *************************************/

 
function enum()
{ /* EUCK! - I need to write my own ENUM data type... tut tut...*/
	$i = func_get_arg(1);
	$j = 2;

	do
	{	
		define(func_get_arg($j), $i+$j-1);
		$j++;
	} while ($j < func_num_args());
}

###########################
# Define()tions           #
###########################

//The Error Types
enum(1, 
        "ERR_DEBUG", //Log if __DEBUG set
        "ERR_INFO", //Log it
        "ERR_NOTIFY", //Log it and echo it
	
	//Only these two are actually errors
	"ERR_WARN", //Log it, echo it and stop execution
        "ERR_PANIC" //Log it, echo it and cripple system
);
					
//The Log Types
define("LOG_RUN", "/msg.log");
define("LOG_ERROR", "/error.log");

//Some fonts - for echoing errors
define("ERR_OPEN", "<div class=error>");
define("ERR_CLOSE", "</div>");


############################
# printl()    
# The main logging frontend
############################

function printl($priority, $message, $file)
{ 
	if( $priority > ERR_PANIC || $priority < ERR_DEBUG)
		printl(ERR_WARN, "Invalid Error Level", __FILE__);

	switch($priority) {
		case ERR_DEBUG: 
			DEBUG($message, $file);
			break;
			
		case ERR_INFO: 
			INFO($message, $file); 
			break;
			
		case ERR_NOTIFY: 
			NOTIFY($message, $file);
			break;
			
		case ERR_WARN: 
			WARN($message, $file);
			break;
			
		case ERR_PANIC: 
			PANIC($message, $file);
			break;
	}

}



######################
# THE ERROR HANDLERS #
######################
/*DONT EVER use these except through printl() */

function DEBUG($message, $file) 
{
	if(defined("__DEBUG__"))
	{
		$fd = open_log(LOG_RUN);
		$string = date("r")
			."\nLevel: DEBUG  File: $file\n\t$message\n\n";
		fwrite($fd, $string);
		close_log($fd);
	}
}

function INFO($message, $file) 
{
	$fd = open_log(LOG_RUN);
	$string = date("r")."\nLevel: INFO  File: $file\n\t$message\n\n";
	fwrite($fd, $string);
	close_log($fd);
}

function NOTIFY($message, $file) 
{
	$fd = open_log(LOG_RUN);
	$string = date("r")."\nLevel: NOTIFY  File: $file\n\t$message\n\n";
	fwrite($fd, $string);
	close_log($fd);
	echo ERR_OPEN.nl2br($string).ERR_CLOSE;
}

function WARN($message, $file) 
{
	$fd = open_log(LOG_ERROR);
	$string = "\n!!WARNING!!  "
		.date("r")."  !!WARNING!!\nFile: $file\n\t$message\n".
		"Stop.\n";
		
	fwrite($fd, $string);
	close_log($fd);
	echo ERR_OPEN.nl2br($string).ERR_CLOSE;
	exit;
}

function PANIC($message, $file) 
{
	$fd = open_log(LOG_ERROR);
	$string = "\n!!!PANIC!!!  "
		.date("r")."  !!!PANIC!!!\nFile: $file\n\t$message\n".
		"Plant Database Terminating\n\n";
		
	fwrite($fd, $string);
	close_log($fd);
	echo ERR_OPEN.nl2br($string).ERR_CLOSE;
	
	/*Knobble it somehow...*/	
}
######################
# The Functions      #
######################

function open_log($log)
{
#	if(!is_writeable($log)) 
#	{ 	//Log is unreadable: logging is imortant, so use another name
#		$tmp = uniqid("");
#		//Only need four random chars
#		$log = "LOG".$tmp[0].$tmp[1].$tmp[2].$tmp[3];
#	}

	$fd = fopen(BCLROOT.$log, "a");
	return $fd;
}


function close_log($fd)
{
	return fclose($fd);
}


?>
