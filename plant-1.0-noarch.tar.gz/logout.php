<?PHP
##################### 
# logout.php v1.0   #
#  Ian Hill GNU GPL #
#####################
# ATM does very     #
# little. Could be  #
# expanded to force #
# a logout.	    #
#####################

include_once("mainfile.php");
include_once(HEADER);

$html = new html;
$html->page = "logout.php";
$html->title = "Logout";
$html->do_header();

echo "<h1>System Logout</h1>
<p>Since security version two it is no longer nessecary to logout from "; echo SITENAME; echo ". Instead, simply closing your browser will secure the system.</p>";
echo "<p>Thank you for your interest in system security.</p>";

$html->do_footer();

