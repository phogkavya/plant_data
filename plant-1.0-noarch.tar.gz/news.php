<?PHP
/*************************************
 * news.php  v1.1		     *
 *************************************
 * Provides a news based front end   * 
 * to Plant database.                *
 *			             *
 * v1.1 - No longer main page - see  *
 *  main.php			     *
 *************************************/

include_once("mainfile.php");
include_once(HEADER);
$html = new html;
$html->page = "news.php";


####################
# display()
#
# Actually outputs 
# the news.
####################

function display() {
do_mysql_connect();
$result =  mysql_query("SELECT * FROM plant.news ORDER BY newsid DESC LIMIT 3");

echo "<br>";

while ($data = mysql_fetch_row ($result)) {
	echo "
	<!-- start of news item -->
	<table border=0 cellpadding=0 cellspacing=1 width=100% class=outline>
	<tr><td>
	<table border=0 cellpadding=2 cellspacing=0 align=center width=\"100%\" 
	class=background>	
	<tr><td class=dark><div class=newstitle>$data[1]</div></td></tr>
	</table>
	
	</td></tr><tr><td>
	
	<table cellpadding=2 border=0 cellspacing=0 width=100% class=background>
	<tr><td class=light><div class=newsbody>$data[2]</div></td></tr>
	</table>
	
	</td></tr><tr><td>
	<table border=0 cellpadding=2 cellspacing=0 width=100% class=background>
	<tr><td class=dark>";
	
	$time = date("j F Y  g:i a", $data[3]);
	
	echo "
	<table width=100%><tr><td width=80% class=dark>
	<p align=left class=newsdate>$time</p></td>
	<td align=right class=dark>
	
	<a href=\"news.php?op=delete_news&delete=$data[0]\">
	<img border=0 src=\"images/delete.gif\" alt=\"Delete\">
	</a>&nbsp;
	
	<a href=\"news.php?op=alter&alter=$data[0]\">
	<img border=0 src=\"images/text.gif\" alt=\"Alter\">
	</a>
	
	</td></tr></table>
	</td></tr></table></tr></table><br>
	<!-- End of news item -->
	";
}

}



#####################
# newrecord()
#
# Displays a form to
# add more news
######################

function newrecord() 
{
	global $html;
	$html->title = "Submit News";
	$html->do_header();
	echo "<h1>Create News Item</h1>
	<br>
	<form method=post action=\"news.php?op=create\">
	<p>News Title</p>
	<input type=\"text\" name=newstitle>
	<p>News body</p>
	<textarea wrap=virtual cols=50 rows=6 name=newsbody></textarea>
	<br>
	<input type=submit name=submit value=\"Create Record\">  
	<input type=reset name=die value=\"Cancel\">
	</form>";
	$html->do_footer();
	exit;
}




###########################
# alterform()
#
# Displays a form for 
# altering a news item
###########################

function alterform($record) 
{
	global $html;
	$html->title = "Alter  News";
	$html->do_header();
	do_mysql_connect();
	$result = mysql_query("SELECT * FROM plant.news WHERE newsid=$record");
	$data = mysql_fetch_row($result);
	echo "<h1>Modify News Item</h1>
	<br>
	<form method=post action=\"news.php\">
	<input type=hidden name=op value=doalter>
	<input type=hidden name=doalter value=$record>
	<p>News Title</p>
	<input class=textbox type=\"text\" name=newstitle value=\"$data[1]\">
	<p>News Body</p>
	<textarea wrap=virtual cols=50 rows=6 name=newsbody>$data[2]</textarea>
	<br><input type=submit name=submit value=\"Alter Record\">
	</form>";
	$html->do_footer();
	exit;
}




###########################
# confdel()
#
# Do you want to delete?
###########################

function confdel($record) 
{
	global $html;
	$html->title = "Delete News Item";
	$html->do_header();
	do_mysql_connect();
	$result = mysql_query("SELECT * FROM plant.news WHERE newsid=\"$record\"");
	
	if ($data = mysql_fetch_row($result)) 
	{ 
		echo "<h1>Delete Record</h1>
		<p>Are you sure you wish to delete record $record?</p>
		<br><p>Title: $data[1]</p><p>Body: $data[2]</p>
		<a href=\"news.php?op=confdel&confdel=$record\">|YES| </a>
		<a href=\"main.php\">|NO|</a>
		</body></html>"; 
	} 
	else 
	{
		echo "<h1>Error</h1>
		<p>The selected record could not be found.</p><br>
		<a href=\"main.php\">Home</a>"; 
	}

	$html->do_footer();
	exit;
}




##############################
# delrecord()
#
# Actually deletes a news 
# item
##############################

function delrecord($record) 
{
	global $html;
	$html->title = "Delete News Item";
	$html->do_header();
	do_mysql_connect();
	if($result = mysql_query("DELETE FROM plant.news 
				WHERE newsid = $record")) 
	{
		echo "<h1>Success</h1>
		</p>Succesfully deleted record $record</p><br>
		<a href=\"main.php\">Home</a>
		</body></html>"; 
	}
	else 
	{
		echo "<h1>Error</h1>
		<p>There was an error deleting record $record.</p>
		<br><a href=\"main.php\">Home</a>"; 
	}
	$html->do_footer();
	exit;
}



#########################
# create()
# 
# Actually creates a 
# news item
#########################

function create($newstitle, $newsbody) {
	global $html;
	$html->title = "Create News Item";
	$html->do_header();
	$newsbody = nl2br($newsbody);
	do_mysql_connect();
	$timestamp = date("U");
	
	$result = mysql_query("INSERT INTO plant.news 
		VALUES(\"\", \"$newstitle\", \"$newsbody\", $timestamp)");

	echo "<h1>Record Created</h1>
	<p>The record you entered has been created. Click 
	<a href=\"main.php\">here</a> to return.</p>\n";
	
	$html->do_footer();
	exit;
}


###############################
# do_alter()
#
# Actually alter a news item
###############################

function do_alter($newsid, $newstitle, $newsbody) 
{
	global $html;
	$html->title = "Delete News Item";
	$html->do_header();
	do_mysql_connect();
	$result = mysql_query("UPDATE plant.news 
				SET newstitle=\"$newstitle\", 
				newsbody=\"$newsbody\" 
				WHERE newsid=\"$newsid\"");
	echo "Record $newsid was sucessfully altered.";
	$html->do_footer();
	exit;
}


###################
# Main 
###################

if(!defined("__WIN32__")) 
	$html->do_auth($PHP_AUTH_USER, $PHP_AUTH_PW);


include_once(HEADER);

switch($op) 
{ //What are we doing here?
	case "delete_news":
		confdel($delete);
		exit;

	case "confdel":
		delrecord($confdel);
		exit;

	case "new":
		newrecord();
		exit;

	case "alter":
		alterform($alter);
		exit;

	case "doalter":
		do_alter($doalter, $newstitle, $newsbody);
		exit;
	
	case "create":
		create($newstitle, $newsbody);
		exit;
}

?>
