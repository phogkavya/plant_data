<?PHP
####################### 
# main.php v1.0       #
#  Ian Hill  GNU GPL  #
#######################
# The Main Frontpage  #
# for Plant Datbase   #
#######################

include_once("mainfile.php");
include_once(HEADER);

$html = new html;
if(!defined("__WIN32__")) 
	$html->do_auth($PHP_AUTH_USER, $PHP_AUTH_PW);

$html->page = "main.php";
$html->title = "Home";
$html->do_header();

include("news.php");

echo "<table width=100% border=0 cellspacing=0 cellpadding=0>
<tr><td width=50%>";
display();
echo "</td><td width=50% valign=top>";
action_items();
echo "</td></tr></table>";

$html->do_footer();


function action_items() 
{
	echo "<br>
	<table width=95% align=center border=0 class=outline cellpadding=0 
		cellspacing=1>
	<tr><td>
	<table width=100% border=0 class=background cellspacing=0 cellpadding=2>
	<tr><td class=dark><b>Action Items</b></td></tr>
	</table>
	</tr></tr><tr><td>
	<table width=100% border=0 class=background cellspacing=0 cellpadding=2>
	<tr><td class=light>";
	$action = 0;

	/*
	 * Check servicing
	 */

	do_mysql_connect();
	$today = time();
	
	$data = mysql_query
		("SELECT registration, ptypeid, lastservice FROM plant");
	while($row = mysql_fetch_row($data))
	{
		$service = mysql_query
			("SELECT service FROM ptype WHERE ptypeid = '$row[1]'");
		$service = implode (mysql_fetch_row($service), "");
		
		$date = (string) $row[2];
	        $day = $date[0].$date[1];
	        $month = $date[2].$date[3] + $service;
		$year = $date[4].$date[5];
	        $date = mktime(0,0,0,$month,$day,$year);
			
		if($date < $today)
		{
			echo "<a href=\"/plant/?op=viewpt&ptypeid=$row[1]\">
				Plant Item Out Of Service
				</a><br>";
		$action = 1;
		}
	}
	

	if ($action == 0)
		echo "No Action Items";

	echo "</td></tr>
		</table>
		</td></tr></table>";
}
