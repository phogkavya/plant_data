#!/bin/bash
########################
#  install.sh          #
#    Ian Hill 2002     #
#                      #
# Bash installer for   #
# PDB                  #
########################

printf "#########################################
#  Welcome to Plant Database Installer  #
#########################################
WARNING: This script MUST be run from within your Apache DocRoot.
If it is not, then press Ctrl+C NOW
Otherwise, press <Enter> to continue...\n\n"
read

printf "Checking for nessecary programs...\nMySQL...."
if mysql --version > /dev/null
then
	printf "Found\n"
else
	printf "NOT FOUND\n"
	printf "I need MySQL!"
	exit
fi



printf "\n\nConfiguration\n^^^^^^^^^^^^^\nPlease enter your site name\n"
read name
printf "\nPlease enter your site's URL\n"
read url
printf "\nPlease enter your contact e-mail address\n"
read adminurl
printf "\nPlease enter your MySQL username\n"
read username
printf "\nPlease enter your MySQL password\n"
read -s password

########################
#  Make config.xml
########################

printf "\nMaking Config.xml......\n\n"

printf "<xml>\n\t<site>\n\t\t<name>$name</name>
\t\t<url>$url</url>\n\t\t<adminurl>$adminurl</adminurl>
\t</site>
\t<files>
\t\t<root>$PWD</root>
\t\t<header>$PWD/header.php</header>
\t</files>
</xml>\n" > config.xml

printf "Creating MySQL Database (You will be prompted for your MySQL password.....\n\n"
mysql -p < plant.sql

printf "Modifying files...\n^^^^^^^^^^^^^^^^^^\n\n"

config="$PWD/config.xml"


mv mainfile.php mainfile.temp
cat mainfile.temp | sed "s/USERNAME/$username/" | sed "s/PASSWORD/$password/"  > mainfile.php
rm mainfile.temp
printf "define(\"CONFIG_XML\", \"$config\");" >> mainfile.php
printf "mainfile.php.....OK\n\n"

printf "
###########################
#  INSTALLATION COMPLETE  #
###########################

To use your new Plant Database, visit $url and log on with these details:

Username: administrator
Password: password

Remember! Passwords are case sensitive!

Consult your user guide for details of adding more users.


Thank you for chosing Plant Database\n"

#Bye.
