<?PHP
/*****************************
 * login.php v2.0            *
 *****************************
 * Provides authentication   *
 * and cookie handling.      *
 *                           *
 * v2.0 Absoletum Obsoletum  *
 *****************************/

include_once("mainfile.php");
include_once(HEADER);
$html = new html;
$html->page="login.php";


function do_login($username) {
global $html;
setcookie("sid", $sid);
header("Location: main.php");
exit;
}

function login_form($DENIED) {
global $html;
$html->title = "Login";
$html->do_header();
echo "<h1>Login</h1>
<p>You must have cookies enabled to proceed beyond this point.</p>";

if($DENIED=="1") { 
echo "<table width=450 bordercolor=#000000 border=1 cellspacing=0><tr><td bgcolor=#cccccc>
<p>The username or password you entered was incorrect. Please try again.</p>
</td></tr></table><br>"; 
}

echo "<table cellspacing=0 cellpadding=0 border=0 width=95% align=center><tr><td>
<table width=15% align=left border=1 cellspacing=0 bordercolor=\"#000000\">
<form method=post action=\"login.php\">
<input type=hidden name=dologin value=1>
<tr><td><p>Username</p>
<input type=\"text\" name=username></td></tr>
<tr><td><p>Password</p>
<input type=\"password\" name=password></td></tr>
<tr bgcolor=\"#cccccc\"><td align=center><input type=submit name=foo value=\"Login\"></td></tr></table>
</form>
</td></tr></table><br>";
$html->do_footer();
exit;
}

function logout() {
global $html;
setcookie("current_user", $current_user, -100);
$html->title = "Logged Out";
$html->do_header();
echo "All Logged Out";
$html->do_footer();
exit;
}


function check_login($username, $password) {
global $html;

if($password=="" || $username=="")
	header("Location: login.php?DENIED=1");

$mysqllink = do_mysql_connect();
$data = mysql_query("SELECT password FROM bcl.users WHERE username=\"$username\"", $mysqllink);
$attempt = mysql_query("SELECT PASSWORD('$password')");
$realpassword = mysql_fetch_row($data);
$fakepassword = mysql_fetch_row($attempt);


if($fakepassword[0]!=$realpassword[0]) {
	header("Location: login.php?DENIED=1");
} else {
	do_login($username); 
}
exit;
}


if(isset($DENIED)) 
	login_form($DENIED);


if(isset($dologin)) {  
	if($username=="" || $password=="") 
	
	{
	header("Location: login.php?DENIED=1"); 
	exit;
	}
	
	else
	
	{
		check_login($username, $password);
	}
}


if(isset($logout))
	logout();

login_form("false");
?>
