<?PHP
/************************************
 * auth.php  v1.0                   *
 *  Ian Hill 2001                   *
 ************************************
 * WWW Auth for BCL Plant Database  *
 ************************************/

class html extends page
{

function do_auth($username='', $password='') 
{

	$username = strtolower($username);
	if ($username=='' || $password=='')
	{
        	header("WWW-authenticate: basic realm=Plant Database");
	        header("HTTP/1.0 401 Unauthorized - Logon failed");
	        include(UNAUTH);
        	exit;
	}
	else 
	{
		$link = do_mysql_connect();
		$data = mysql_query("SELECT password 
				FROM plant.users 
				WHERE username=\"$username\"");
	
		$realpass = mysql_fetch_row($data);
		$data = mysql_query("SELECT PASSWORD('$password')");
		$pass = mysql_fetch_row($data);

		if ($realpass[0] != $pass[0]) 
		{
		  header("WWW-authenticate: basic realm=Plant Database");
		  header("HTTP/1.0 401 Unauthorised"); 
		  include(UNAUTH);	
		}
	}

}
}

?>
