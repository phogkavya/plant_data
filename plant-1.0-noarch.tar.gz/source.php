<?PHP
include_once("mainfile.php");
include_once(HEADER);
$html = new html;
$html->page = "source.php";
if(!defined("__WIN32__")) 
	$html->do_auth($PHP_AUTH_USER, $PHP_AUTH_PW);

##################################
#  soure.php                     #
#   Displays my code in glorious #
#   technicolor                  #
##################################
# Ian Hill 2001   - GNU GPL      #
##################################


#####################
# Functions
#####################

function err_page_undef() 
{
	/* Syntax Error*/
	global $html;
	$html->title = "Error 404";
	$html->do_header();
	echo "The URL you used did not specify a file. Please try again.";
	echo "<br><br>If this was a link from our site, please report it.";
	$html->do_footer();
	/*We should log this event*/
	exit;	
}

function security_err($foo) 
{
	global $html;
	$html->title = "Security Alert";
	$html->do_header();
	echo "<h1>SECURITY ALERT</h1>";
	echo "The URL used tried to read a file outside our security field.";
	$html->do_footer();
	exit;
}

function four_oh_four() 
{
	global $html;
	$html->title = "Error 404";
	$html->do_header();
	echo "<h1>HTTP/1.1 404</h1>
	<p>The file you specified could not be found.
	<br><br><p>If you entered the address yourself, please try again. 
	If you followed a link from one of my pages, please 
	<a href=mailto:\"".ADMINURL."\">report</a> it.
	<br>
	<br>
	<br>
	<i>Error  404 in ".__FILE__."</i>";
	$html->do_footer();;
	exit;
}


####################
# Main Routine
####################

if(!isset($page)) 	
	err_page_undef(); 

if(stristr($page, "config"))
	security_err("Config");
	
if(stristr($page, "mainfile")) 
	security_err("Mainfile.php"); 
	
if($page[0]=="." || $page[1]=="." || $page[0]=="/" ) 
	security_err($foo); 
	
if(!file_exists($page)) 
	four_oh_four(); 


$html->title = "Viewing Source";

if(!isset($noheaders)) 
{
	/* 
	  Set $noheaders to remove 
	  the headers from the 
	  source, making it suitable 
	  for printing.
	*/
	$html->do_header();
}

echo "<h1 class=sourcetitle>$page</h1>";
show_source($page);

if(!isset($noheaders)) 
	$html->do_footer();
	
?>
