<?PHP
/************************
 *  time.php v1.0       *
 *  (C) Ian Hill 2001   *
 *                      *
 * Display Global Times *
 ************************/
include_once("mainfile.php");
include_once(HEADER);

$html = new html;
$html->title = "Date Manipulation";
$html->page = "time.php";

//Arrays are the only thing complex enough to need declaring
$tz = array( 
	array( 
		'city' => 'NULL', 
		'diff' => 'NULL'
	) 
);

//Some cities and their hour differences from GMT
$tz[0]['city'] = "Vancouver";
$tz[0]['diff'] = "-8";

$tz[]['city'] = "Chicago";
$tz[1]['diff'] = "-6";

$tz[]['city'] = "Toronto";
$tz[2]['diff'] = "-5";

$tz[]['city'] = "New York";
$tz[3]['diff'] = "-5";

$tz[]['city'] = "Buenos Aires";
$tz[4]['diff'] = "-3";

$tz[]['city'] = "London";
$tz[5]['diff'] = "+0";

$tz[]['city'] = "Amsterdam";
$tz[6]['diff'] = "+1";

$tz[]['city'] = "Cairo";
$tz[7]['diff'] = "+2";

$tz[]['city'] = "Moscow";
$tz[8]['diff'] = "+3";

$tz[]['city'] = "Tokyo";
$tz[9]['diff'] = "+9";

$html->do_header();


echo "<h1>International Times</h1>
<table width=60% class=outline cellspacing=1 cellpadding=0>
<tr><td>
<table width=100% class=background>";

foreach($tz as $t) {
	echo "\n<tr align=center><td>".$t['city']."</td><td>";
	$diff = $t['diff'];
	/*
	 * Trickery!
	 * time() returns the number of seconds since the epoch.
	 * date("Z") returns the number of seconds that this machine
	 * is past GMT
	 * $diff * 3600 is the number of seconds our destination TZ is ahead
	 * of GMT
	 */
	$date = time() - date("Z") + $diff*3600;
	echo date("g:i A l jS", $date);
	echo "</td></tr>";
	} 

echo "</table></td></tr></table>";
$html->do_footer();
?>

