<?PHP
/*********************************
 * admin.php v1.0                *
 *********************************
 * Administrative interface to   *
 * BCL Plant Database.           *
 *********************************/

include_once("../mainfile.php");
include_once(HEADER);
$html = new html;

if(!defined("__WIN32__")) 
	$html->do_auth($PHP_AUTH_USER, $PHP_AUTH_PW); 

if(!isadmin())
{ //Should we be here??
	include(UNAUTH);
	die;
}

$html->page="admin/admin.php"; 

#if(!isset($current_user)) { header("Location: login.php"); } //Old System

if(!isset($op)) 
	$op = "viewusers"; 

switch($op){
    case "viewusers":
    	view_users();
	exit;

    case "deleteuser":
    	conf_user_delete($delete); /* $delete is actually $username*/
	exit;

   case "deluserconf":
   	do_user_delete($delete); /* $delete is actually $username*/
	exit;

   case "alteruser":
   	alter_user_form($alter); /*$alter is actually $username*/
	exit;

   case "altuserconf":
   	do_user_alter($alter); /*and more*/
	exit;

   case "newuser":
	new_user_form();
	exit;
	
   case "DoUserCreate":
   	verify_user_create();
	exit;
}



#######################
# view_users
#
# Displays user manager
#######################
function view_users() {
	global $html;
	$html->title = "Current Users";
	$html->do_header();
	
	global $current_user;
	
	echo "<h1>Current Users</h1>";
	
	$mysqllink = do_mysql_connect();
	$result = mysql_query("SELECT * FROM users ORDER BY username");
	
	echo "
	<table width=80% align=center class=outline cellspacing=1 
	cellpadding=0 border=0>
	<tr><td>
	<table width=100% border=0 cellpadding=3 cellspacing=0 class=background>
	<tr><td>
	<tr class=dark>
	
	<td width=10% class=newstitle>UID</td>
	<td class=newstitle width=30%>User Name</td>
	<td class=newstitle width=50%>Full Name</td>
	<td class=newstitle WIDTH=10%>Ops</td>
	</tr></table>
	</td></tr>
	<tr><td>";

while($data = mysql_fetch_row($result)) 
	{
	echo "
	<!--One User-->
	<table width=100% border=0 cellpadding=3 cellspacing=0 class=background>
	<tr><td width=10%>$data[0]</td>   <!-- UID -->
	<td width=30%>$data[1]</td>       <!-- Username -->
	<td width=50%>$data[2]</td>       <!-- Full Name -->
	<td width=10%>                    <!-- Ops -->
		<a href=\"admin.php?op=deleteuser&delete=$data[1]\">
		<img border=0 src=\"/images/delete.gif\" alt=\"Delete\">
		</a>&nbsp;
	</td></tr></table>
	</td></tr>
	<tr><td>
	<!-- End of User-->
	\n";
	}

	echo "
	<table width=100% border=0 cellpadding=3 cellspacing=0 class=background>
	<tr>
	<td class=dark align=center>
	<a href=\"admin.php?op=newuser\">
	<img src=\"/images/new.gif\" border=0 alt=\"New\"> New</a>
	
	</td></tr>
	</table>
	</td></tr></table>
	<br>";
	$html->do_footer();
	exit;	
}


##############################
# conf_user_delete
#
# Prompts before deleting user
##############################
function conf_user_delete($username) 
{
	global $html;
	$html->title = "Delete User";
	$html->do_header();
	echo "<h1>Delete User</h1>
	<p>Are you sure you wish to delete $username?</p>
	<a href=\"admin.php?op=deluserconf&delete=$username\">YES</a>
	<a href=\"admin.php?op=viewusers\">NO</a>";
	$html->do_footer();
}



##########################
# do_user_delete
#
# Actually deletes a user
##########################
function do_user_delete($username) 
{
	global $html;
	$html->title = "Delete User";
	$html->do_header();

	do_mysql_connect();
	$result = mysql_query
		("DELETE FROM plant.users WHERE username=\"$username\"");

	if($result)
	{
		echo "<h1>User Deleted</h1>";
		echo "User $username was deleted.";
	} 
	else 
	{
		echo "<h1>Error</h1><p>An error occurded upon deletion</p>";
	}
	
	$html->do_footer();
}




#############################
# new_user_form()
#
# Presents the User Edit Form
##############################

function new_user_form($username="", $fullname="", $message="") 
{
	global $current_user;
	global $html;
	$html->title = "New User";
	$html->do_header();
	echo "<h1>Create User</h1>";
	if($message != "") 
		echo"<p>$message</p>"; 
	echo "
	<table width=95% align=center border=0 cellspacing=0 cellpadding=0>
	<tr><td>
	
	<table width=40% align=left border=0 cellspacing=1 cellpadding=0 
	class=outline><tr><td>
	
	<table width=100% cellspacing=0 cellpadding=3 class=background border=0>
	
	<form action=\"admin.php\" method=\"POST\">
	<input type=hidden name=op value=\"DoUserCreate\">
	
	<tr><td class=dark><div class=newstitle>User Details</div></td></tr>
	</table>	
	
	</td></tr>
	<tr><td>
	
	<table width=100% cellspacing=0 cellpadding=3 class=background border=0>
	<tr><td><p>Username: 
		<input type=text name=\"username\" value=\"$username\"></p>
	</td></tr>
	
	<tr><td><p>Full Name: 
		<input type=text name=\"fullname\" value=\"$fullname\"></p>
	</td></tr>
	
	<tr><td><p>Password: 
		<input type=password name=\"pass1\"></p>
	</td></tr>
	
	<tr><td><p>Confirm Password: 
		<input type=password name=pass2></p>
	</td></tr>
	
	</table>
	
	</td></tr>
	<tr><td>
	
	<table width=100% cellspacing=0 cellpadding=3 class=background border=0>
	<tr>
	<td class=dark><div class=newstitle>Privileges</div></td>
	</tr>
	</table>
	
	</td></tr>
	<tr><td>
	
	<table width=100% cellspacing=0 cellpadding=3 class=background border=0>
	<tr><td><p><div class=newstitle>News</div></p>
	<p><input type=checkbox name=\"news_submit\">May Submit News</p>
	<p>
	<input type=checkbox name=\"news_modify\">May Modify Or Delete News
	</p>
	</td></tr></table>
	
	</td></tr>
	<tr><td>
	
	<table width=100% cellspacing=0 cellpadding=3 class=background border=0>
	<tr><td>
	<p><b>Admin</b></p>
	<p><input type=checkbox name=\"admin\">May Administrate</p></tr></td>
	</table>
	
	</td></tr>
	<tr><td>
	
	<table width=100% cellspacing=0 cellpadding=3 class=background border=0>
	<tr><td class=dark align=center>
	<input type=submit name=foo value=\"Create\">
	</td></tr>
	
	</form>
	</table>
	</td></tr></table>
	</td></tr></table>
	
	<br>";
	$html->do_footer();
	exit;
}

###############################
# verify_user_create()
#
# Actually creates a user
###############################
function verify_user_create() 
{
	global $username, $pass1, $pass2, $fullname, $admin, $news_submit, $news_modify, $html;

/*Check Passwords*/

	if($pass1 != $pass2) 
	{
new_user_form($username, $fullname, "The passwords you entered do not match."); 
	}
		
	if($pass1 == "") 
	new_user_form($username, $fullname, "Please dont use blank passwords"); 


	/*Check Username*/
	$mysqllink = do_mysql_connect();
	$result = mysql_query
		("SELECT * FROM plant.users WHERE username=\"$username\"");
	
if(mysql_num_rows($result) > 0) 
{ 
new_user_form
	($username, $fullname, "The username you entered is already taken."); 
}

	/*Privileges*/
	if(isset($admin)) 
	{ 
		$admin = "y";  
	} 
	else 
	{
		$admin = "n"; 
	}

	if(isset($news_submit)) 
	{ 
		$news_submit = "y"; 
	}
	else
	{ 
		$news_submit="n"; 
	}

	if(isset($news_modify)) 
	{ 
		$news_modify = "y"; 
	}
	else
	{ 
		$news_modify="n"; 
	}

	/*All is well; lets create this account...*/
	$username = strtolower($username);
	
	$create = mysql_query("INSERT INTO users 
		VALUES(\"\", 
		\"$username\", 
		\"$fullname\", 
		PASSWORD('$pass1'), 
		\"\", 
		\"$news_submit\", 
		\"$news_modify\", 
		\"$admin\")");
	
	$html->do_header();
	echo "<h1>Created</h1><p>Foo</p>";
	$html->do_footer();
}

?>
