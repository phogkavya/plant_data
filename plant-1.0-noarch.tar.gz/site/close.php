<?PHP
/***************************
 * site/close.php v1.0     *
 *   Ian Hill 2002         *
 *                         *
 * Close a site            *
 ***************************/

if(!defined("INDEX"))
	header("Location: /site/");

if(!isset($op))
	header("Location: /site/");

if(!isset($sid))
	header("Location: /site/");
	
$html = new html;
$html->title = "Close Site";
$html->page = "site/close.php";
$html->do_header();

if($op == "close")
{
	echo "<h1>Close Site</h1>";
	echo "<p>Are you sure you wish to close site $sid?</p>";
	echo "<a href=\"/site/?op=doclose&sid=$sid\">YES</a>
	&nbsp;
	<a href=\"/site/\">NO</a>";
}
else
{
	do_mysql_connect();
	$data = mysql_query("SELECT * FROM hire WHERE sid='$sid'
		AND signedoff=''");
	if(mysql_num_rows($data) != 0)
	{
		echo "<p>Unable to close site: hires outstanding.</p>";
	}
	else
	{
		mysql_query("UPDATE sites SET active='0' WHERE sid='$sid'");
		if(mysql_affected_rows() != 1)
		{
			echo "<p>An error occured during DB Update</p>";
		}
		else
		{
			echo "<h1>Site Closed</h1>";
		}
	}
}

$html->do_footer();
