<?PHP
/***************************
 *  site/display.php v1.0  *
 *     Ian Hill 2002       *
 *                         *
 * Display known sites     *
 ***************************/

if(!defined("INDEX"))
	header("Location: /site/");

$html = new html;
$html->title = "Site Manager";
$html->page = "site/display.php";
$html->do_header();

echo "<h1>Site Manager</h1>
<table width=95% class=outline border=0 cellpadding=0 cellspacing=1 
	align=center>
<tr><td>
<table width=100% class=background border=0 cellpadding=4 cellspacing=0>
<tr align=center class=dark>
<b>
<td width=15%><b>Contract Number</b></td>
<td width=35%><b>Site Name</b></td>
<td width=25%><b>Site Manager</b></td>
<td width=10%><b>Number</b></td>
<td width=15%><b>Ops</b></td>
</tr>
</table>";

do_mysql_connect();
$data = mysql_query("SELECT * FROM sites WHERE active='1' ORDER BY cid");

while($row = mysql_fetch_row($data))
{
	$rdata = mysql_query
		("SELECT hid FROM hire WHERE sid = '$row[0]' 
		AND signedoff=''");
	$number = mysql_num_rows($rdata);
	echo "<tr><td>
	<table width=100% class=background border=0 cellpadding=4 
		cellspacing=0>
	<tr>
	<b>
	<td align=center width=15%>$row[1]</td>
	<td width=35% align=center>$row[2]</td>
	<td width=25% align=center>$row[3]</td>
	<td width=10% align=center>
		<a href=\"/hire/?op=bysite&sid=$row[0]\">$number</a></td>
	<td width=15% align=center>
		<a href=\"/site/?op=close&sid=$row[0]\">Close</a>
	</td>
	</tr>
	</table>";
	
}
echo "<tr><td><table width=100% class=background border=0 cellpadding=4
      cellspacing=0>
	<tr class=dark align=center><td>
	<a href=\"/site/?op=create\">
		<img src=\"/images/new.gif\" border=0>
		New Site
	</a>
	</table>
	</table>";
$html->do_footer();
