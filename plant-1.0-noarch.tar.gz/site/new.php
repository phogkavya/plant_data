<?PHP
/*************************
 * site/new.php   v1.0   *
 *    Ian Hill 2002      *
 *                       *
 * Make new sites        *
 *************************/

if(!defined("INDEX"))
        header("Location: /site/");

$html = new html;
$html->title = "Add New Site";
$html->page = "site/new.php";

if($op == "create")
{
	$html->do_header();
	echo "<h1>Add Site</h1>";
	echo "<form action=\"/site/?op=docreate\" method=post>
		<table width=70% class=outline cellpadding=0 cellspacing=1
		border=0 align=center>
		<tr><td>
		<table width=100% class=background cellpadding=4 
		cellspacing=0 border=0>
		<tr class=dark><td>
		<div class=error>$message&nbsp;</div>
		</table>
		<tr><td>
		<table width=100% class=background cellpadding=4
		cellspacing=0 border=0>
		<tr><td>
		Site Name:
		<td><input type=text name=sname>
		<tr><td>
		Site Manager:
		<td><input type=text name=sman>
		<tr><td>
		Contract Number:
		<td><input type=text name=cid>
		</table>
		<tr><td>
		<table width=100% class=background cellpadding=4
		cellspacing=0 border=0>
		<tr class=dark align=center>
		<td><input type=submit value=Create>
		</table>
		</table>";
				
}
else
{
	if(!isset($sname) || !isset($sman) || !isset($cid))
	{
		header("Location: /site/?op=create");
		exit;
	}
	
	do_mysql_connect();
	$data = mysql_query("SELECT * FROM sites WHERE sname='$sname'");

	if(mysql_num_rows($data) != 0)
	{
		header
		 ("Location: /site/?op=create&message=Site%20Name%20Taken");
		exit;
	}
	
	if(!ereg("^[1-9][0-9]+$", $cid))
	{
	header
	("Location: /site/?op=create&message=Contract%20Number%20Invalid");
	exit;
	}
	
	$html->do_header();
	mysql_query("INSERT INTO sites VALUES
		(\"\",
		\"$cid\",
		\"$sname\",
		\"$sman\",
		\"1\")");
	echo "<h1>Site Added</h1>";
}
$html->do_footer();
