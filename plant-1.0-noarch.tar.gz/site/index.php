<?PHP
/******************************
 *  site/index.php  v1.0      *
 *    Ian Hill 2002           *
 *                            *
 *  Redirector                *
 ******************************/

include_once("../mainfile.php");
include_once(HEADER);
$html = new html;

if(!defined("__WIN32__"))
        $html->do_auth($PHP_AUTH_USER, $PHP_AUTH_PW);

//Just so everyone knows we're here
define("INDEX", "TRUE");

if(!isset($op))
        $op = "display";

switch($op)
{
	case display:
	include("display.php");
	exit;
	
	case close:
	include("close.php");
	exit;

	case doclose:
	include("close.php");
	exit;
	
	case create:
	include("new.php");
	exit;
	
	case docreate:
	include("new.php");
	exit;
}
