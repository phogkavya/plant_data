#
#  plant.sql
#    Ian Hill 2002
#
#  Database Structure for Plant Database
#  Complete as of Version One (PDB)
#


CREATE DATABASE plant;
USE plant;

#
# Table structure for table 'hire'
#


DROP TABLE IF EXISTS hire;
CREATE TABLE hire (
  hid int(10) NOT NULL auto_increment,
  pid int(10) default NULL,
  sid int(10) default NULL,
  uid int(10) default NULL,
  dateon tinyblob,
  dateoff tinyblob,
  signedon blob,
  signedoff blob,
  notes blob,
  PRIMARY KEY  (hid)
) TYPE=MyISAM;

#
# Table structure for table 'menu'
#

DROP TABLE IF EXISTS menu;
CREATE TABLE menu (
  menuid int(10) NOT NULL auto_increment,
  menutext tinyblob,
  menutarget blob,
  PRIMARY KEY  (menuid)
) TYPE=MyISAM;

#
# Data for table 'menu'
#

INSERT INTO menu VALUES (1,'Home','/main.php');
INSERT INTO menu VALUES (2,'News Manager','/news.php?op=new');
INSERT INTO menu VALUES (3,'Hire Manager','/hire/');
INSERT INTO menu VALUES (4,'Plant Manager','/plant/');
INSERT INTO menu VALUES (5,'Site Manager','/site/');
INSERT INTO menu VALUES (20,'Admin','text');
INSERT INTO menu VALUES (21,'User Manager','/admin/');

#
# Table structure for table 'news'
#

DROP TABLE IF EXISTS news;
CREATE TABLE news (
  newsid int(10) NOT NULL auto_increment,
  newstitle blob,
  newsbody blob,
  timestamp tinyblob,
  PRIMARY KEY  (newsid)
) TYPE=MyISAM;

INSERT INTO news VALUES (1, 'Welcome To Plant Database', 'Congratulations! You have successfully installed Plant Database!', '0');
#
# Table structure for table 'plant'
#

DROP TABLE IF EXISTS plant;
CREATE TABLE plant (
  pid int(10) NOT NULL auto_increment,
  ptypeid int(10) default NULL,
  registration tinyblob,
  lastservice tinyblob,
  notes blob,
  onhire int(1) default NULL,
  PRIMARY KEY  (pid)
) TYPE=MyISAM;

#
# Table structure for table 'ptype'
#

DROP TABLE IF EXISTS ptype;
CREATE TABLE ptype (
  ptypeid int(10) NOT NULL auto_increment,
  name blob,
  full blob,
  price blob,
  service blob,
  PRIMARY KEY  (ptypeid)
) TYPE=MyISAM;

#
# Table structure for table 'sites'
#

DROP TABLE IF EXISTS sites;
CREATE TABLE sites (
  sid int(10) NOT NULL auto_increment,
  cid int(10) default NULL,
  sname tinyblob,
  sman tinyblob,
  active int(1) default NULL,
  PRIMARY KEY  (sid)
) TYPE=MyISAM;

#
# Table structure for table 'users'
#

DROP TABLE IF EXISTS users;
CREATE TABLE users (
  uid int(10) NOT NULL auto_increment,
  username tinyblob,
  fullname tinyblob,
  password tinyblob,
  last_access tinyblob,
  news_submit tinyblob,
  news_modify tinyblob,
  admin tinyblob,
  PRIMARY KEY  (uid)
) TYPE=MyISAM;

INSERT INTO users VALUES ('', 'administrator', 'Administrator', '5d2e19393cc5ef67', '', '', '', 'y');

