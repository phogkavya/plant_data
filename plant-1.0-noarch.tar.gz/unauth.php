<?PHP
/*************************
 * unauth.php v1.0       *
 * Ian Hill 2001         *
 *************************
 * Access denied page    *
 *************************/

include_once(HEADER);

$html = new html;
$html->title = "Unauthorised";
$html->page = "unauth.php";
$html->do_header();

echo "<h1>Access Denied</h1>
<p>Access to this area of ".SITENAME." is restricted to those with valid 
authentication details. If you believe you should be allowed access please 
contact your administrator.</p>";

$html->do_footer();
exit;
?>
