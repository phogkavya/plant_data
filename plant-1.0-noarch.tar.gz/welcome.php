<?PHP
/##############################
# welcome.php v1.0           #
#  Ian Hill 2001             #
#                            #
# Pretty welcome page before #
# WWW auth begins            #
##############################/


include_once("mainfile.php");
include_once(HEADER);

$html = new html;
$html->page = "welcome.php";
$html->title = "Welcome";
$html->do_header();
echo "<h1>Welcome to ".SITENAME.
	"</h1><p>To proceed you must have valid authentication details.</p>
	<p>If you have them, then click <a href=\"main.php\">here</a> 
	to continue, otherwise you need to contact your administrator</p>";
$html->do_footer();
