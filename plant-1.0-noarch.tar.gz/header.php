<?PHP
/************************************
 * header.php  v2.0                 *
 ************************************
 * Headers for BCL Plant Database   *
 *                                  *
 * v2.0 Old style headers are out.  *
 * Instead, header.php provides     *
 * html::, wich contains these      *
 * functions, and more...           *
 ************************************/

class page {

var $title;
var $page;

function do_header() {

/* DEPRECATED
global $current_user;
if(!isset($current_user)) 
{ 
	$user = "Not Logged In"; 
} 
else 
{ 
	$user = $current_user; 
}
*/

global $PHP_AUTH_USER;

if(!isset($PHP_AUTH_USER)) 
{
	$user ="Not Logged In"; 
} 
else 
{	
	$user = $PHP_AUTH_USER; 
}


echo "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">

<html><head>
<title>".SITENAME." - $this->title </title>
<meta name=\"Author\" content=\"Ian Hill\">
<meta http-equiv=\"Content-type\" Content=\"text/html\" charset=\"iso-8859-15\">
<link rel=\"stylesheet\" href=\"/style.css\">
</head>

<body>
<!-- Head Table -->
<table  width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"5\">
  <tr valign=center>
    <td width=\"18%\"> 
      <table cellspacing=\"1\" cellpadding=\"0\" width=\"100%\" border=\"0\" class=outline><tr><td>
      <table cellspacing=0 border=0 class=background>
        <tr> 
          <td valign=center width=\"25%\" height=\"63\" class=light> 
            <p align=center><a href=\"/main.php\"><img src=\"/images/logo.gif\" alt=\"".SITENAME."\" width=\"152\" border=\"0\" height=\"52\"></a></p>
          </td>
        </tr>
      </table>
      </td></tr></table>
    </td>
    <td width=\"81%\">
      <table class=outline cellspacing=\"1\" cellpadding=\"0\" width=\"100%\" border=0><tr><td>
      <table class=background cellspacing=0 border=0 cellpadding=0 width=\"100%\">
        <td valign=center  width=\"80%\" height=\"63\" class=light> 
          <div class=maintitle>".SITENAME."</div>
        </td>
        </tr>
      </table>
      </td></tr></table>
    </td>
  </tr>
</table>
<!-- END Head Table -->
<br>
<!--  Body Table -->
<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"5\">
    <tr>
      <td valign=\"top\" width=\"12%\"> 
        <!-- Nav Table -->		
	<table cellpadding=\"0\" cellspacing=\"1\" width=100%=\"0\" border=\"0\" class=\"outline\">
	<tr><td>
	<table cellpadding=\"10\" cellspacing=\"0\" border=\"0\" class=\"background\" width=100%>
	<tr><td class=light>
	<div class=menutitle>Navagation</div>
	<table cellpadding=\"5\" cellspacing=\"0\" border=\"0\">
	";

do_mysql_connect();
$data = mysql_query("SELECT menutext, menutarget FROM menu ORDER BY menuid");

while ($row = mysql_fetch_row($data)) {
	if($row[1]!="text") 
	{
		echo "<tr><td>
		<a class=menuitem href=\"$row[1]\">$row[0]</a>\n</td></tr>\n";
	} 
	else 
	{
		echo "</table>
		<div class=menutitle>$row[0]</div>
		<table cellpadding=5 cellspacing=0 border=0 width=100%>";
	}	
}


echo "</table>
	</td></tr></table>
	</td></tr></table>
	<!-- END menu table -->
	<br>

	<!-- Date/time/user Table -->
	<table width=100% border=0 cellspacing=1 cellpadding=0 class=outline>
	<tr><td>
	<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"10\" class=background>
	<tr><td class=light>
	
	<div class=menutitle>Date</div>
	
	<table width=100% cellspacing=0 cellpadding=5><tr><td class=menuitem>"; 
	$date = date("l F j, Y"); 
	echo "$date";
	echo "</td></tr></table>
	<div class=menutitle>Time</div>
	<table width=100% cellspacing=0 cellpadding=5><tr><td class=menuitem>"; 
	
	$time = date("g:i A T");
	echo "<a href=\"/time.php\" class=\"menuitem\">$time</a>"; 
	echo "</td></tr></table>";
	
if(!defined("__WIN32__")) 
{
	echo"<div class=menutitle>Current User</div>";
	echo "<table width=100% cellspacing=0 cellpadding=5><tr><td>";
	
	if($user=="Not Logged In") 
	{ 
		echo "<a href=\"main.php\" class=menuitem>$user</a>"; 
	}
	else
	{
		echo "<a href=\"/logout.php\" class=menuitem>$user</a>"; 
	}
	
	
	echo "</td></tr></table>";
}//__WIN32__

echo "</td></tr></table>
</td></tr></table>";

if(defined("__SFNET__")) 
{ //Hosting logo - used only during testing.
	echo "
	<br>
	 <table width=100% cellspacing=1 cellpadding=0 class=outline border=0>
        <tr><td>
	<table width=100% border=0 cellspacing=0 cellpadding=3 class=background>
	<tr><td align=center valign=center>
        <A href=\"http://sourceforge.net\">
	<IMG src=\"http://sourceforge.net/sflogo.php?group_id=36939&type=1\" 
	width=\"88\" height=\"31\" border=\"0\"  alt=\"SourceForge Logo\"></A>
	</td></tr></table></td></tr></table>"; 
}//__SFNET__
echo "

	<!-- END date/user etc TABLE -->
	
      </td>
      <!-- body cell -->
      <td width=\"75%\" valign=\"top\">

	<table width=100% border=0 cellspacing=1 cellpadding=0 class=outline>
	<tr><td>
	<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"10\" class=background>
          <tr> 
            <td valign=top class=light>
	    <!-- End of Header-->\n\n";
}




function do_footer() {
echo "
	<!-- start of footer-->
		</td>
          </tr>
        </table>
      </td>
    </tr>
  </table>
  </tr></td></table>
<br>
  
  <table width=\"100%\" border=\"0\" cellspacing=\"1\" cellpadding=\"0\" class=outline><tr><td>
  <table width=100% cellspacing=0 cellpadding=0 class=background><tr><td class=light>
      <p align=center><i>".SITENAME." - For use only by authorised employees. - <a href=\"/source.php?page=";
	  echo $this->page;
	  echo "\">View Source</a></i></p></td>
    </tr>
  </table></td></tr></table>

</body>
</html>";
}
}

include(BCLROOT."/auth.php");
