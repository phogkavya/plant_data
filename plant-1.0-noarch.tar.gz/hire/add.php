<?PHP
##########################
#  /hire/add.php v1.0    #
##########################
# Provides the functions #
# for adding hires	 #
##########################

##################
# Main
##################
if(!defined("INDEX"))
	header("Location: /hire/");

switch($op)
{  /* What are we doing here? */

case "newhire": /* Stage one */
	newhire();
	exit;

case "newhire2": /* Stage Two */
	newhire2($ptypeid);
	exit;
	
case "hireconf":  /* Confirmation */
	hireconf($ptypeid, $pid, $sid, $dateon);

case "addhire":  /* We're in business */
	addhire($ptypeid, $pid, $sid, $dateon, $win32); 
	exit;
}


###########################
# newhire()
#
# First form for adding a
# hire
###########################

function newhire() 
{
	global $PHP_AUTH_USER;
	global $html;
	
	$html->page = "hire/add.php";
	$html->title = "Hire an item";
	$html->do_header();

	do_mysql_connect();
	$data = mysql_query
		("SELECT ptypeid, name FROM ptype ORDER BY name");
	?>

	<table width=95% align=center border=0 cellspacing=0 cellpadding=0>
	<tr><td>
	<h1>New Hire</h1>
	<table width=40% align=left border=0 cellpadding=0 cellspacing=1
		class=outline>
	<tr><td>
	
	<table width=100% border=0 cellspacing=0 class=background>
	<form action="/hire/index.php?op=newhire2" method="POST">
	<tr>
	<td class=dark><div class=newstitle>New Hire</div>
	</td>
	</tr>
	</table>
	
	</td></tr>
	<tr><td>
	
	<table width=100% border=0 cellspacing=0 cellpadding=3 class=background>
	<tr><td>
	<p>Plant Class  <select name=ptypeid>
	<?PHP
		while ($row = mysql_fetch_row($data)) 
		{
			echo "<option value=\"$row[0]\">$row[1]</option>";
		}
	?>
	</p>
	</td></tr>
	</table>
	
	</td></tr>
	<tr><td>
	
	<table class=background width=100% border=0 cellpadding=0 cellspacing=0>
	<tr><td class=dark align=center>
	<input type=submit name=foo value="Next">
	</td></tr>
	</table>
	
	</td></tr></table>
	
	</td></tr></table><br>
	
	<?PHP
	$html->do_footer();
}
	
###########################
# newhire2()
#
# Second stage hire
# Pick a plant item, and a 
# location
############################
function newhire2($ptypeid) 
{
	global $html;
	$html->page = "hire/add.php";
	$html->title = "Add Hire - Stage Two";
	$html->do_header();
	do_mysql_connect();
	
	
	$result = mysql_query
		("SELECT name 
		FROM ptype 
		WHERE ptypeid = \"".$ptypeid."\"");
		
	$ptype = mysql_fetch_row($result);
	
	$sites = mysql_query
		("SELECT sid, sname FROM sites WHERE active='1' ORDER BY sname");

	$plant = mysql_query
		("SELECT pid, registration 
		FROM plant 
		WHERE ptypeid = '$ptypeid' 
		AND onhire = '0'");
	
	if(mysql_affected_rows() == 0)
		no_free(); 
	
	?>
	<h1>New Hire</h2>
	<form action="/hire/index.php?op=hireconf" method=post>
	<input type=hidden name="ptypeid" value="<?PHP echo $ptypeid; ?>">
	
	<table width=95% align=center border=0 cellspacing=0 cellpadding=0>
	<tr><td>

	<table width=50% align=left border=0 cellpadding=0  cellspacing=1 
	class=outline>
	<tr><td>
	
	<table width=100% border=0 cellpadding=3 cellspacing=0 class=background>
	<tr><td class=dark>
	<div class=newstitle>New Hire</div>
	</td></tr>
	</table>
	
	</td></tr>
	<tr><td>
	
	<table width=100% border=0 cellpadding=3 cellspacing=0 class=background>
	<tr><td><p>Plant Type: <?PHP echo $ptype[0]; ?></p></td></tr>
	<tr><td><p>Registration Number: <select name=pid>
	
	<?PHP 
	while($row = mysql_fetch_row($plant)) 
	{ 
		echo "<option value=$row[0]>$row[1]</option>\n"; 
	} 
	?>
	
	</select>
	</p></td></tr>
	<tr><td>	
	<p>Site: <select name=sid>
	
	<?PHP 
	while($row = mysql_fetch_row($sites)) 
	{ 
		echo "<option value=$row[0]>$row[1]</option>"; 
	} 
	?>
	
	</select>
	</p></td></tr></table>
	</td></tr><tr><td>
	<table width=100% border=0 cellpadding=3 cellspacing=0 class=background>
	<tr><td>Date On: <input type=text name=dateon value="DD/MM/YY">
	</td></tr></table>
	<tr><td>
	<table width=100% border=0 cellpadding=3 cellspacing=0 class=background>
	<tr><td class=dark align=center>
	<input type=submit value="Next"></td></tr>
	</table>
	</table>
	</table>	
	<?PHP
	$html->do_footer();
}


#################################
# no_free()
#
# What happens if theres no free 
# plant
#################################
function no_free() 
{
	echo "<h1>No Free Plant</h1>
	<p>I'm sorry, there is no free plant of that type.</p>
	<a href=\"/hire/?op=newhire\">Return</a>";
	exit; //Log this? Might allow people to decide to order new plant...
}


##############################
# hireconf()
#
# Checks for errors, and lets
# you verify your choices.
##############################
function hireconf($ptypeid, $pid, $sid, $dateon) 
{

	global $html;
	global $PHP_AUTH_USER;
	$html->title = "Hire Details";
	$html->page = "hire/add.php";
	$html->do_header();
	$error = 0;
	do_mysql_connect();

	/* Get hire details */
	
	/* NB: If I were desperate for speed  *
	 * I could get all these with one     *
	 * query, but I dont see the point.   *
	 * Lets leave it as a possible future *
	 * optimisation 		      */ 
   
	if(!defined("__WIN32__")){
	$data = mysql_query
		("SELECT fullname 
		FROM plant.users 
		WHERE username = \"".strtolower($PHP_AUTH_USER)."\"
		");

		if(mysql_affected_rows() != 1) 
		{
		$fullname = "<div class=error>Error Obtaining User Name</div>";
		$error = 1;
		} 
		else 
		{
		$fullname = implode(mysql_fetch_row($data), ""); 
		}
	} 
	else 
	{  
		$fullname = "<input type=hidden name=win32 value=99999>";
	} //win32

	$data = mysql_query("SELECT * FROM plant.plant WHERE pid = '$pid'");


	if(mysql_affected_rows() != 1)
	{
		$error = 2;
		$error_string = "<div class=error>
			Error Finding Specified Plant
			</div>";
	}

	$data = mysql_query
		("SELECT name FROM plant.ptype WHERE ptypeid = \"$ptypeid\"");


	if(mysql_affected_rows() != 1) 
	{
		$ptype = "<div class=error>Invalid Plant Type</div>";
		$error = 1;
	}
	else
	{
		$ptype = implode(mysql_fetch_row($data), "");
	}
	
	$data = mysql_query
		("SELECT sname FROM plant.sites WHERE sid = \"$sid\"");

	if(mysql_affected_rows() != 1) 
	{ 
		$site = "<div class=error>Error Determining Site Name</div>";
		$error = 1;
	}
	else
	{
		$site = implode(mysql_fetch_row($data), "");
	}

	if(!ereg("([0-9]{2})/([0-9]{2})/([0-9]{2})", $dateon)) 
	{
		$error = 2;
		$error_string = "<div class=error>Error in date format</div>";
	}
		
	echo "<h1>New Hire</h1>
	<table width=95% align=center border=0 cellspacing=1 cellpadding=0 
	class=outline>
	<tr><td>
	<table width=100% border=0 cellspacing=0 cellpadding=3 class=background>
	<tr><td class=dark>
	<form action = \"/hire/index.php?op=addhire\" method=post>
	<div class=newstitle>Hire Details</div>
	</td></tr></table>
	</td></tr><tr><td>
	<table width=100% border=0 cellspacing=0 cellpadding=3 class=background>
	<tr><td class=dark>
	<p>Buyer Name: $fullname</p>
	<p>Plant Type: $ptype</p>
	<input type=hidden name=ptypeid value=$ptypeid>
	<p>Site: $site</p>
	<input type=hidden name=sid value=$sid>
	<p>Date On: $dateon</p>
	<input type=hidden name=dateon value=$dateon>
	<input type=hidden name=pid value=$pid>
	</td></tr></table>
	</td></tr><tr><td>
	<table width=100% border=0 cellspacing=0 cellpadding=3 class=background>
	";
	
	switch($error) 
	{
	
	case 0: //No errors - lets go ahead
		echo "<tr><td align=center>
		<input type=submit value=Confirm></td></tr>";
		exit;
	
	case 1: //Error already highlighted, - lets go back
		echo "<tr><td align=center>
		<a href=\"/hire/?op=newhire\">Go Back</a></td></tr>";
		exit;
	
	case 2: //Display deffered error - lets go back
	        echo "<tr><td align=center>$error_string<br>
		<a href=\"/hire/?op=newhire\">Go Back</a></td></tr>";
		exit;
	}	
	
	echo "</table>
	</td></tr></table>
	<br>";
	
	$html->do_footer();
	exit;
}


########################
# addhire()
#
# Actually add the hire
########################
function addhire($ptypeid, $pid, $sid, $dateon,  $win32='') 
{
	/*By this point we assume all is well.*/
	global $html;
	$html->do_header();
	do_mysql_connect();
	if($win32 != '') 
	{
		$uid = 99999;
	}
	else
	{
		$uid = get_uid();
	}
	mysql_query
		("INSERT into plant.hire VALUES
		('', '$pid', '$sid', '$uid', '$dateon', '', '', '', '')"); 
		
	$hid = mysql_insert_id();
	mysql_query("UPDATE plant.plant SET onhire='1' WHERE pid='$pid'");
	echo "<h1>Plant Hired</h1>";
	
}
