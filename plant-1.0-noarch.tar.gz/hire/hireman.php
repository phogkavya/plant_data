<?PHP
/*********************************
 *  hire/hireman.php v1.0        *
 *    Ian Hill 2002              *
 *                               *
 * Management system for current *
 * hires                         *
 *********************************/

if(!defined("INDEX"))
	header("Location: /hire/");

	
$html->page = "hire/hireman.php";
switch ($op) 
{ //What are we doing here?
	case hireman:
		hireman();
		exit;	

	case bysite:
		bysite($sid);
		exit;
	
	case byptype:
		byptype($ptypeid);
		exit;

	case byreg:
		byreg($reg);
		exit;
}


###############################
#  hireman()
#
# Our main entry point
# How would we like our plant
# served?
###############################
function hireman() 
{
	global $html;
	$html->page = "hire/hireman.php";
	$html->title = "Hire Management";
	$html->do_header();

	echo"<H1>Hire Management</h1>
	<p>Please select an operation.</p>
	<table width=50% align=middle cellpadding=0 cellspacing=1 class=outline border=0>
	<tr><td>
	<table width=100% cellpadding=10 cellspacing=0 class=background border=0>
	<tr align=center><td><a href=\"/hire/?op=newhire\">New Hire</a></td></tr>
	<tr align=center><td><a href=\"/hire/?op=bysite\">List By Site</a></td></tr>
	<tr align=center><td><a href=\"/hire/?op=byptype\">List By Plant Type</a></td></tr>
	</table>
	</td></tr></table>";
	
	$html->do_footer();
}

function byptype($ptypeid)
{
global $html;
$html->title="List By Plant Type";
$html->do_header();
if($ptypeid == '')
{ // We dont know our ptype, lets get some choices
	echo "<h1>Select A Plant Type</h1>
	<table width=50% align=center cellpadding=0 cellspacing=1
		class=outline border=0>
	<tr><td>
	<table width=100% cellpadding=5  cellspacing=0 class=background 
		border=0>
	<tr><td align=center>
	<form action=\"/hire/?op=byptype\" method=post>
	<select name=ptypeid>
	";

	do_mysql_connect();
	$data = mysql_query("SELECT * FROM ptype");
	
	while($ptype = mysql_fetch_row($data))
	{
		echo"<option value=\"$ptype[0]\">$ptype[2]</option><br>";
	}
	
	echo"</select></td></tr>
	</table></td></tr>
	<tr><td>
	<table width=100% cellpadding=5  cellspacing=0 class=background 
		border=0>
	<tr class=dark><td align=middle><input type=submit value=\"Select\">
	</td></tr></table></td></tr></table>";
}
else
{
	echo "<h1>Listing By Plant Type</h1>
	<p>Listing for plant type: ``".ptypeid2full($ptypeid)."''</p>
	<table width=90% align=left class=outline cellpadding=0 cellspacing=1 border=0>
	<tr><td>
	<table width=100% class=background cellspacing=0 border=0>
	<tr class=dark align=center> 
	<td width=10% class=newstitle>HID</td>
	<td width=30% class=newstitle>Registration Number</td>
	<td width=20% class=newstitle>Site</td>
	<td width=20% class=newstitle>Date On</td>
	<td width=10% class=newstitle>Ops</td></tr>
	</table>
	<tr><td>
	<table width=100% class=background cellspacing=0 border=0>";
	$data = mysql_query("SELECT hire.hid,
		plant.registration, sites.sname, 
		hire.dateon, hire.signedon,hire.signedoff
	        FROM hire
	        JOIN ptype
	        JOIN plant
		JOIN sites
	        WHERE hire.pid = plant.pid
		AND sites.sid = hire.sid
                AND plant.ptypeid = ptype.ptypeid
                AND plant.ptypeid='$ptypeid' AND signedoff=''
	        ORDER BY plant.registration");
	
	while($item = mysql_fetch_row($data))
	{
		echo "<!-- Plant Item -->
		<tr align=center>
		<td width=10%>$item[0]</td>
		<td width=30%>$item[1]</td>
		<td width=20%>$item[2]</td>";
		
		if($item[4] == "")
		{
			echo "<td width=20%>Pending</td>";
		}
		else
		{
			echo "<td width=20%>$item[3]</td>";
		}
		
		echo "<td width=10%>";

		if($item[4] == "")
                {
			echo "<a href=\"/hire/?op=onprompt&hid=$item[0]\">
			<img border=0 src=\"/images/gtick.png\">
			</a>";
		}
		
		if($item[5] == "")
		{
			echo "<a href=\"/hire/?op=offprompt&hid=$item[0]\">
			<img border=0 src=\"/images/rtick.png\">
			</a>";
		}
	}	
	echo"</td>\n\n";
	echo"</tr></table></td></tr></table>";
}
$html->do_footer();
}
######################################
# bysite()
#
# List all plant at a given site, 
# else list all available sites
######################################
function bysite($sid = '')
{
global $html;
$html->title="List By Site";
$html->do_header();

if($sid == '')
{ // We dont know our site, lets get some choices
	
	echo "<h1>Select A Site</h1>
       <table width=50% align=center cellpadding=0 cellspacing=1 class=outline border=0>
       <tr><td>
       <table width=100% cellpadding=5  cellspacing=0 class=background border=0>
       <tr><td align=center>
       <form action=\"/hire/?op=bysite\" method=post>
       <select name=sid>
       ";
	
	do_mysql_connect();
	$data = mysql_query("SELECT * FROM sites WHERE active='1'");
	while($site = mysql_fetch_row($data))
	{
		echo"<option value=\"$site[0]\">$site[2]</option><br>";
	}
	echo"</select></td></tr>
	</table></td></tr>
	<tr><td>
	<table width=100% cellpadding=5  cellspacing=0 class=background border=0>
	<tr class=dark><td align=middle><input type=submit value=\"Select\">
	</td></tr></table></td></tr></table>";
}
	
else
	
{ /* We already know our site...*/
	echo "<h1>List By Site</h1>
	<p> Listing for site ``".sid2sname($sid)."''</p>
	<table width=90% align=left border=0 cellpadding=0 cellspacing=1 
	class=outline>
	<tr><td>
	<table width=100% border=0 cellspacing=0 class=background>
	<tr class=dark align=center>
	<td width=10% class=newstitle>HID</td>
	<td width=30% class=newstitle>Type</td>
	<td width=30% class=newstitle>Registration Number</td>
	<td width=20% class=newstitle>Date On </td>
	<td width=10% class=newstitle>Ops</td>
	</tr></table>
	</td></tr>
	<tr><td>
	<table width=100% border=0 cellspacing=0 class=background>
	";

	/**WARNING: Magic Follows: Handle With Care!**/
	$data = mysql_query("SELECT hire.hid, 
	ptype.name, plant.registration, hire.dateon, hire.signedon, 
	hire.signedoff 
	FROM hire
	JOIN ptype 
	JOIN plant 
	WHERE hire.pid = plant.pid 
		AND plant.ptypeid = ptype.ptypeid 
		AND sid='$sid' AND signedoff='' 
	ORDER BY ptype.name");
	
	while($item = mysql_fetch_row($data))
	{
		echo "
		<!-- Plant Item -->
		<tr align=center>
		<td width=10%>$item[0]</td>
		<td width=30%>$item[1]</td>
		<td width=30%>$item[2]</td>";
		if($item[4] == "")
		{
			echo "<td width=20%>Pending</td>";
		}
		else
		{
			echo "<td width=20%>$item[3]</td>";
		}
		echo "<td width=10%>";

		if($item[4] == "")
		{
			echo "<a href=\"/hire/?op=onprompt&hid=$item[0]\">
			<img border=0 src=\"/images/gtick.png\">
			</a>
			";
		}
		if($item[5] == "")
		{
			echo "<a href=\"/hire/?op=offprompt&hid=$item[0]\">
			<img border=0 src=\"/images/rtick.png\">
			</a>";
		}	
		echo"</td>\n\n";	
		
	}

	echo"</tr></table></td></tr></table>";
} 
$html->do_footer();
}
