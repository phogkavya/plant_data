<?PHP
/*************************
 * /hire/sign.php  v1.0  *
 *   Ian Hill 2002       *
 *                       *
 * Sign plant on and off *
 *************************/

if(!defined("INDEX"))
	header("Location: /hire/");

$html->page = "/hire/sign.php";
switch($op) 
{  //What are we doing here?
	case signon:
		signon($hid, $name, $notes);
		exit;

	case signoff:
		signoff($hid, $name, $notes);
		exit;

	case onprompt:
		onprompt($hid);
		exit;
	
	case offprompt:
		offprompt($hid);
		exit;
}

#############################
# prompt()
# 
# As both signing on and off
# use identical forms, use
# one procedure.
#############################
function prompt($hid, $onoff)
{
	global $html;
	$html->title="Sign $onoff";
	$html->do_header();
	
	do_mysql_connect();
	
	$data = mysql_query("SELECT 
	hire.hid, plant.registration, ptype.full, sites.sname, hire.notes
	FROM hire
	JOIN plant
	JOIN ptype
	JOIN sites
	WHERE hire.pid = plant.pid
	AND hire.sid = sites.sid
	AND plant.ptypeid = ptype.ptypeid
	AND hire.hid = '$hid'");
	
	
	$data = mysql_fetch_row($data);
	echo "<h1>Sign $onoff</h1>
	<p>Signing $onoff one ``$data[2]'' ($data[1]) to site ``$data[3]''</p>
	<br>
	<table width=50% class=outline cellpadding=0 cellspacing=1  border=0>
	<tr><td>
	<table width=100% class=background cellpadding=5 cellspacing=0 border=0>
	<tr class=dark><td><b>Sign $onoff</b></td></tr>
	</table>
	</td></tr>
	<tr><td>
	<form action=\"/hire/?op=sign$onoff\" method=post>
	<input type=hidden name=\"hid\" value=\"$hid\">
	<table width=100% class=background cellpadding=5 cellspacing=0 border=0>
	<tr><td>Signatory:</td><td><input class=text name=name></td></tr>
	<tr><td>Notes:</td>
	<td><textarea name=notes>$data[4]</textarea></td></tr>
	</table>
	</td></tr>
	<tr><td>
	<table width=100% class=background cellpadding=5 cellspacing=0 border=0>
	<tr class=dark><td><input type=submit value=\"Sign $onoff\"></td></tr>
	</table>
	</td></tr></table>
	";
	$html->do_footer();
}

###########################
# signon()
#
# Mark plant as arrived
###########################
function signon($hid, $name, $notes='')
{
	global $html;
	$html->title="Plant Signed On";
	$html->do_header();
	do_mysql_connect();
	$today = date("d/m/y");
	mysql_query("UPDATE hire SET signedon='$name' WHERE hid='$hid'");
	mysql_query("UPDATE hire SET dateon='$today' WHERE hid='$hid'");
	if($notes != '')
		mysql_query("UPDATE hire SET notes='$notes' WHERE hid='$hid'");
	
	echo "<h1>Sign On</h1>
	<p>Hire $hid was successfully signed on.</p>";
	$html->do_footer();
}

##############################
# signedoff()
#
# Mark plant as having left
##############################
function signoff($hid, $name, $notes='')
{
	global $html;
	do_mysql_connect();
	$data = mysql_query("SELECT pid FROM hire WHERE hid='$hid'");
	$pid = implode(mysql_fetch_row($data), "");
	$today = date("d/m/y");
	mysql_query("UPDATE hire SET dateoff='$today' WHERE hid='$hid'");
	mysql_query("UPDATE hire SET signedoff='$name' WHERE hid='$hid'");
	mysql_query("UPDATE plant SET onhire = '0' WHERE pid = '$pid'");

	if($notes != '')
	{
		mysql_query("UPDATE hire SET notes='$notes' WHERE hid='$hid'");
	}
	$html->title = "Signed Off";
	$html->do_header();

	$query = mysql_query("SELECT ptypeid FROM plant WHERE pid='$pid'");
	$ptypeid = implode(mysql_fetch_row($query), "");
	
	$query = mysql_query("SELECT ptype.price, hire.dateon 
				FROM ptype
				JOIN hire
				WHERE ptype.ptypeid='$ptypeid'
				AND hire.hid='$hid'");
	$data = mysql_fetch_row($query);
	
	/*
	 * $today is of the format dd/mm/yy
	 * NOT ddmmyy; don't forget the / when calculating
	 * the time!
	 */
	
	/*
	 * Algorithm used: 
	 * * Split dates into $days, $months and $years
	 * * Calculate the number of seconds, since the epoch, until those dates
	 * * Subtract dateoff from dateon
	 * * Divide by 86400 to get number of days
	 * * Multiply by price-per-day
	 */
	 
	$dateon = $data[1];
	$days = $dateon[0].$dateon[1];
	$months = $dateon[3].$dateon[4];
	$years = $dateon[6].$dateon[7];
	$dateon = mktime("0", "0", "0", $months, $days, $years);
	
	$days = $today[0].$today[1];
	$months = $today[3].$today[4];
	$years = $today[6].$today[7];
	$dateoff = mktime("0", "0", "0", $months, $days, $years);
	
	$date = $dateoff - $dateon;
	$date = $date/86400; //86400 == 60" * 60' * 24h = seconds in one day
	$cost = $data[0] * $date;
	
	echo "<h1>Signed Off</h1>
	<p>Plant successfully signed off.</p>
	<p>Hire cost was: �$cost";
	
	$html->do_footer();
}

########################
# (on|off)prompt()
#
# Wrappers around 
# prompt()
########################
function onprompt($hid)
{
	prompt($hid, "on");
	exit;
}

function offprompt($hid)
{
	prompt($hid, "off");
	exit;
}
