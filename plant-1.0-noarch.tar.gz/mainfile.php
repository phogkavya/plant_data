<?PHP
/**************************************
* mainfile.php v2.0                   *
*   Ian Hill                          *
*                                     *
* This file contains global functions.*
* This should be the ONLY file with   *
* usernames/passwords in, as its the  *
* only one shielded from source.php   *
*                                     *
* Also includes C Style Prototypes,   *
*                                     *
* v1.1 - Merged with config.php       *
* v2.0 - XML Config                   *
***************************************/

########################
# The config stuff
########################
$docroot = ereg_replace("/mainfile.php", "", __FILE__);
define("CONFIG_XML", "$docroot/config.xml");


$fd = fopen(CONFIG_XML, "r"); 
$xmldata = fread($fd, 1048567); //NOTE: size limitation at 1MB

/******************
 * <location> tag *
 ******************/
/*
 * I don't set these to FALSE if they dont exist, 'cos thats still
 * is_defined() passable.
 */
$location = one_parse("location", $xmldata);

if(one_parse("sourceforge", $location) == "TRUE") 
	define("__SFNET__", "TRUE"); 
	
if(one_parse("win32", $location) == "TRUE") 
	define("__WIN32__", "TRUE"); 

if(one_parse("debug", $location) == "TRUE")
	define("__DEBUG", "TRUE");

/**************
 * <site> tag *
 **************/
$site = one_parse("site", $xmldata);
define("SITENAME", one_parse("name", $site));
define("SITEURL", one_parse("url", $site));
define("ADMINURL", one_parse("adminurl", $site));

/***************
 * <files> tag *
 ***************/
 
$files = one_parse("files", $xmldata);
define("BCLROOT", one_parse("root", $files));
define("HEADER", one_parse("header", $files));

/*
  These aren't really configs, but its good to keep
  all define()s together
*/

define("UNAUTH", BCLROOT."/unauth.php");
define("CONFIG", BCLROOT."/config.php");

##############################
# string one_parse()
#
# Parse an XML stream
# (Does NOT support comments)
##############################

function one_parse($element, $xml)
{
	$temp = explode("<$element>", $xml);
	$string = explode("</$element>", $temp[1]);
	return (string) $string[0];
}


##########################
# int do_mysql_connect()
#
# Connect to MySQL DB
##########################

function do_mysql_connect() 
{
	$link = mysql_connect("localhost", "USERNAME", "PASSWORD");
	mysql_select_db("plant");
	return $link;
}

############################
# int get_uid()
#
# Get current UID
############################

function get_uid() 
{
	global $PHP_AUTH_USER;
	$user = strtolower($PHP_AUTH_USER);
	$data = mysql_query("SELECT uid FROM users WHERE username='$user'");
	$uid = implode(mysql_fetch_row($data), "");
	return $uid;
}

#############################
# string sid2sname()
#
# Get sitename from sid
#############################

function sid2sname($sid)
{
	do_mysql_connect();
	$data = mysql_query("SELECT sname FROM sites WHERE sid='$sid'");
	$data = mysql_fetch_row($data);
	return (string) $data[0];
}


#############################
# string ptypeid2full
#
# Get full from ptypeid
#############################

function ptypeid2full($ptypeid) 
{
	do_mysql_connect();
	$result = mysql_query
		("SELECT full FROM ptype WHERE ptypeid='$ptypeid'");
		
	$result = implode(mysql_fetch_row($result), "");
	return (string) $result;
}

#############################
# int isadmin()
#
# Are we administrators?
#############################

function isadmin()
{
	do_mysql_connect();
	$result = mysql_query
		("SELECT admin FROM users WHERE uid='".get_uid()."'");
	$result = implode(mysql_fetch_row($result), "");
	if($result == "y")
		return 1;
	return 0;
}
/*
 * This include() comes last because
 * we need to have all the define()s
 * in place before we can use BCLROOT.
 * Fortunately, PHP4 lets us call
 * functions before we've actually 
 * defined them
 */

include_once(BCLROOT."/log.php");
