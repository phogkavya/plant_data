<?PHP
/***************************
 * /plant/index.php v1.0   *
 *    Ian Hill 2002        *
 *                         *
 *  Redirector             *
 ***************************/

include_once("../mainfile.php");
include_once(HEADER);
$html = new html;

if(!defined("__WIN32__"))
	$html->do_auth($PHP_AUTH_USER, $PHP_AUTH_PW);
	
//Just so everyone knows we're here
define("INDEX", "TRUE");

if(!isset($op))
	$op = "display";

switch($op)
{
	case display:
	include("display.php");
	exit;
	
	case ptype:  
	include("ptype.php");
	exit;
	
	case modpt:
	include("ptype.php");
	exit;
	
	case domodpt:
	include("modptype.php");
	exit;

	case viewpt:
	include("plant.php");
	exit;

	case delplant:
	include("modplant.php");
	exit;

	case dopdel:
	include("modplant.php");
	exit;
	
	case service:
	include("service.php");
	exit;

	case newitem:
	include("makeplant.php");
	exit;

	case additem:
	include("makeplant.php");
	exit;

	case newpt:
	include("ptype.php");
	exit;

	case addpt:
	include("makept.php");
	exit;
}


