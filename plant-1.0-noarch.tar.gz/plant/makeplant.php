<?PHP
/*******************************
 * plant/makeplant.php   v1.0  *
 *     Ian Hill 2002           *
 *                             *
 * Add new plant               *
 *******************************/

if(!defined("INDEX"))
        header("Location: /plant/");

$html = new html;
$html->page = "plant/makeplant.php";
$html->title = "New Plant Item";
$html->do_header();

if($op == "newitem")
{  //Show a form
	if(!isset($ptypeid))
		header("Location: /plant/");
		
	echo "<h1>New Plant</h1>
	<table width=50% class=outline align=center border=0 cellpadding=0
		cellspacing=1>
	<tr><td>
	<table width=100% border=0 class=background cellpadding=4 
		cellspacing=0>
	<tr><td align=center class=dark>
	<b>".ptypeid2full($ptypeid)."</b>
	</td></tr>
	</table>
	<tr><td>
	<table width=100% border=0 class=background cellpadding=4
		cellspacing=0>
	<tr><td align=center>
	Registration Number:
	<form action=\"/plant/?op=additem\" METHOD=\"POST\">
	<input type=hidden name=ptypeid value=$ptypeid>
	<input type=text name=registration>
	</table>
	<tr><td>
	<table width=100% border=0 class=background cellpadding=4
		cellspacing=0>
	<tr><td align=center class=dark>
	<input type=submit value=\"Create\">
	</table></table>";

	$html->do_footer();
			
}
else
{  //Actually make it
	if(!isset($ptypeid))
		header("Location: /plant/");
	
	if(!isset($registration))
		header("Location: /plant/?op=newitem");
	
	do_mysql_connect();
	$today = date("dmy");

	mysql_query
		("INSERT INTO plant 
		VALUES(\"\",".        //PID
		"\"$ptypeid\",".      //ptypeid
		"\"$registration\",". //Registration 
		"\"$today\",".        //lastservice
		"\"\",".              //notes 
		"\"0\")");            //onhire
	
	if(mysql_affected_rows() != 1)
	{
		echo "<h1>An error ocurred adding plant to Database</h1>";
	}
	else
	{
		echo "<h1>Plant Added</h1>";
	}

	$html->do_footer();

}
