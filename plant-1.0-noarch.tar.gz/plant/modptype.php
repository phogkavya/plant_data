<?PHP
/*****************************
 * /plant/modptype.php v1.0  *
 *   Ian Hill 2002           *
 *                           *
 * Modify Plant Type         *
 *****************************/

if(!defined("INDEX"))
	header("Location: /plant/");

$html = new html;
$html->page = "/plant/modptype.php";
$html->title = "Modifying Plant";
$html->do_header();
$error = 0;


do_mysql_connect();
if(!isset($ptypeid))
{
	printl(ERR_WARN, "Plant Type Not Specified", __FILE__);
	$error = 1;
}
else
{
	$data = mysql_query
		("SELECT * FROM ptype WHERE ptypeid = '$ptypeid'");
	
	if(mysql_num_rows($data) == 0)
	{
		printl(ERR_WARN, "Plant Type Not Found", __FILE__);
		$error = 1;
	}
	else
	{
		mysql_query
			("UPDATE ptype SET name = '$name', 	
			full = '$full', 
			price = '$price',".
			"service = '$service' 
			WHERE ptypeid = '$ptypeid'");
	}	
}

if($error == 0)
	echo "<h1>Plant Modified</h1>";
