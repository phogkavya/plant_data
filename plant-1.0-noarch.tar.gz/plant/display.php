<?PHP
/****************************
 * plant/display.php v1.0   *
 *   Ian Hill 2002          *
 *                          *
 * Front menu for plant     *
 * management               *
 ****************************/

if(!defined("INDEX")) //Don't let us in if we didnt come from index.php 
	header("Location: /plant/");

$html = new html;
$html->title = "Plant Management";
$html->page = "plant/display.php";
$html->do_header();

echo "<h1>Plant Management</h1>
<table width=85% border=0 cellspacing=1 cellpadding=0 class=outline align=center>
<tr><td>
<table width=100% border=0 cellspacing=0 cellpadding=2 class=background>
<tr class=dark align=center>
<td width=40%><b>Plant Type</b></td>
<td width=20%><b>Number</b></td>
<td width=20%><b>Price per day</b></td>
<td width=20%><b>Ops</b></td>
</tr></table>
</td></tr>";

do_mysql_connect();
$data = mysql_query("SELECT name, price, ptypeid FROM ptype ORDER BY name");
while($row = mysql_fetch_row($data))
{
	$i = mysql_query
		("SELECT pid FROM plant WHERE ptypeid = '".$row[2]."'");
	$number = mysql_num_rows($i);
	echo "
	<tr><td>
	<table width=100% border=0 cellspacing=0 cellpadding=2 class=background>
	<tr align=center>
	<td width=40%>".$row[0]."</td>
	<td width=20%><a href=\"/plant/?op=viewpt&ptypeid=$row[2]\">"
		.$number."</a></td>
	<td width=20%>".$row[1]."</td>
	<td width=20%>
		<a href=\"/plant/?op=modpt&ptypeid=$row[2]\">Edit</a>
		<a href=\"/hire/?op=newhire2&ptypeid=".$row[2]."\">Hire</a>
		<a href=\"/plant/?op=newitem&ptypeid=$row[2]\">New</a>
	</td>
	
	</tr>
	</table>
	</td></tr>
	";	
}
	
echo "<tr><td><table width=100% border=0 cellpadding=2 cellspacing=0 class=background>
	<tr><td class=dark align=center>
	<a href=\"/plant/?op=newpt\">
		<img src=\"/images/new.gif\" border=0 alt=\"New Plant Type\">
		New Plant Type
	</a>
	</td></tr>
	</table>
	</td></tr>
	</table>";
$html->do_footer();
