<?PHP
/***************************
 * /plant/ptype.php  v1.0  *
 *  Ian Hill 2002          *
 *                         *
 * Plant Type Manager      *
 ***************************/

if(!defined("INDEX"))
	header("Location: /plant/");

$html = new html;
$html->page = "plant/ptype.php";
$html->title = "Plant Type Manager";
$html->do_header();
do_mysql_connect();

$result = array();

echo "<h1>Plant Type Manager</h1>";
if(isset($ptypeid)) 
{
	$data = mysql_query("SELECT * FROM ptype WHERE ptypeid='$ptypeid'");
	$result = mysql_fetch_row($data);
	echo "<h2>Viewing Plant Type $result[0]: $result[2]</h2>";
	echo "<form action=\"/plant/?op=domodpt\" method=post>";
}
else
{
	echo "<form action=\"/plant/?op=addpt\" method=post>";
}
echo "<table cellpadding=0 cellspacing=1 class=outline>
<tr><td>
<table width=\"100%\" cellpadding=2 cellspacing=0 class=background>
<tr class=dark><td>
&nbsp;
</table>
<tr><td>
<table width=\"100%\" cellpadding=2 cellspacing=0 class=background>
<tr align=center><td>
Short Name: <input type=text name=name value=\"$result[1]\" size=50>
<tr align=center><td>
Full Name: <input type=text name=full value=\"$result[2]\" size=51>
</table>
<tr><td>
<table width=\"100%\" cellpadding=2 cellspacing=0 class=background>
<tr align=center><td>
Price Per Day (Pounds Sterling): 
	<input type=test name=price value=\"$result[3]\">
<td>
Service Period (Months): 	
	<input type=text name=service value=\"$result[4]\">
</table>
<tr><td>
<table width=\"100%\" cellpadding=2 cellspacing=0 class=background>
<tr class=dark align=center><td>";

if(isset($ptypeid))
	echo "<input type=hidden value=$ptypeid name=ptypeid>";

echo "<input type=submit value=\"Submit\">
</table>
</table>
";
$html->do_footer();
