<?PHP
/********************************
 *  plant/plant.php v1.0        *
 *      Ian Hill 2002           *
 *                              *
 *  Display plant.              *
 ********************************/

if(!defined("INDEX"))
	header("Location: /plant/");

$html = new html;
$html->page = "plant/plant.php";
$html->title = "Listing By Type";
$html->do_header();

echo "<h1>Listing Plant</h1>
<h2>Of Type \"".ptypeid2full($ptypeid)."\"</h2>";
	
if(!isset($ptypeid))
	header("Location: /plant/");
	
do_mysql_connect();
$data = mysql_query
	("SELECT * FROM plant WHERE ptypeid = '$ptypeid'
	ORDER BY registration");

echo "<table width=70% class=outline cellpadding=0 cellspacing=1 
	border=0 align=centeR>
	<tr><td>
	<table width=100% cellpadding=4 cellspacing=0 class=background>
	<tr align=center class=dark>
	<td width=50%><b>Registration</b></td>
	<td width=25%><b>Last Service</b></td>
	<td width=25%><b>Ops</b></td>
	</tr>
	</table>
	</td></tr>";
	
while($row = mysql_fetch_row($data)) 
{ 
	$date = (string) $row[3];
	$day = $date[0].$date[1];
	$month = $date[2].$date[3];
	$year = $date[4].$date[5];
	$date = mktime(0,0,0,$month,$day,$year);
	$date = date("d F Y", $date);
	
	echo "<tr><td>
	<table width=100% cellpadding=3 cellspacing=0 class=background>
               <tr align=center>
               <td width=50%>$row[2]</td>
               <td width=25%>$date</td>
               <td width=25%>
		<a href=\"/plant/?op=delplant&pid=$row[0]\">
			<img src=\"/images/delete.gif\" border=0>
		</a>
		&nbsp;
		<a href=\"/plant/?op=service&pid=$row[0]\">
			<img src=\"/images/new.gif\" border=0>
		</a>
		</td>
               </tr>
               </table>
               </td></tr>";	 
}
echo "<tr><td>
	<table width=100% cellpadding=3 cellspacing=0 class=background>
	<tr align=center class=dark>
	<td>  
	<a href=\"/plant/?op=newitem&ptypeid=$ptypeid\">
		<img src=\"/images/new.gif\" border=0>
		New Item
	</a>			
	</table>
	</table>";
$html->do_footer();
