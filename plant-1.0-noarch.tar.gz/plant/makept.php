<?PHP
/*****************************
 * plant/makept.php    v1.0  *
 *    Ian Hill 2002          *
 *                           *
 * Make a new plant type     *
 *****************************/

if(!defined("INDEX"))
	header("Location: /plant/");

if(!isset($full) || !isset($name) || !isset($price) || !isset($price))
	header("Location: /plant/?op=newpt");

$html = new html;
$html->page = "plant/makept.php";
$html->title = "New Plant Type";
$html->do_header();

do_mysql_connect();
mysql_query("INSERT INTO ptype VALUES".
	"(\"\",".        //ptypeid
	"\"$name\",".    //name
	"\"$full\",".    //full
	"\"$price\",".   //price
	"\"$service\"". //serivce
	")");
	
if(mysql_affected_rows() != 1)
{
	echo "<p>An error ocurred when adding your plant type.</p>";
}
else
{
	echo "<h1>Plant Type Added</h1>";
}

$html->do_footer();
