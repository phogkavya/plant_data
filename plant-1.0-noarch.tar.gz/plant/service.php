<?PHP
/*********************************
 * plant/service.php  v1.0       *
 *     Ian Hill 2002             *
 *                               *
 * Servicing plant               *
 *********************************/

if(!defined("INDEX"))
	header("Location: /plant/");

if(!isset($pid))
	printl(ERR_WARN, "PID Not Specified", __FILE__);

$html = new html;
$html->page = "plant/service.php";
$html->title = "Updating Service History";
$html->do_header();

do_mysql_connect();

$date = date("dmy");

mysql_query("UPDATE plant SET lastservice = '$date' WHERE pid = '$pid'");

echo "<h1>Updated</h1>
<p>Plant Item $pid was updated</p>";

$html->do_footer();
