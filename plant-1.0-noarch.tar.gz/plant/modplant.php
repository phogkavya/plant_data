<?PHP
/********************************
 *   plant/modplant.php v1.0    *
 *       Ian Hill 2002          *
 *                              *
 *  Delete Plant Items          *
 ********************************/

if(!defined("INDEX"))
	header("Location: /plant/");

if(!isset($pid))
	header("Location: /plant/");

if(!isset($op)) //Sanity Check
	header("Location: /plant/");

if(!isadmin())
	include("../unauth.php");

$html = new html;
$html->page = "plant/modplant.php";

if($op == "delplant")
{
	$html->title = "Delete Plant?";
	$html->do_header();

	do_mysql_connect();
	$data = mysql_query("SELECT onhire FROM plant WHERE pid = '$pid'");
	if(implode(mysql_fetch_row($data),"") == "1")
	{
		echo "<h1>Unable to delete</h1>
		<p>Unable to delete: plant on hire.</p>";
	}
	else
	{
	echo"<h1>Delete Plant?</h1>
	<p>Are you sure you wish to delete this plant item?</p>
	<a href=\"/plant/?op=dopdel&pid=$pid\">YES</a>
	&nbsp;
	<a href=\"/plant/\">NO</a>";
	}
	$html->do_footer();
}
else
{
	do_mysql_connect();
	mysql_query("DELETE FROM plant WHERE pid = '$pid'");
	$html->title = "Deleted Plant";
	$html->do_header();
	echo "<h1>Plant Deleted</h1>";
	$html->do_footer();
}
